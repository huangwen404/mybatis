package org.apache.ibatis.amapper;

import org.apache.ibatis.apojo.Role;

public interface RoleMapper {
    public org.apache.ibatis.apojo.Role getRole(Long id);
    public Role findRole(String roleName);
    public int deleteRole(Long id);
    public int insertRole(Role role);
}
